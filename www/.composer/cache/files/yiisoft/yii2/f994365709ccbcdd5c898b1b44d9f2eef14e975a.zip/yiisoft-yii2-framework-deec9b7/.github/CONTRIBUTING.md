Contributing to Yii 2
=====================

Please use [yiisoft/yii2](https://github.com/yiisoft/yii2) to report issues and send pull requests. Thank you!
