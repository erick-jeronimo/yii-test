Yii BR Validator
================

1.1.1 Jun, 19 2020
------------------

- PHP 7.4 compatibility ([#13](https://github.com/yiibr/yii2-br-validator/pull/13)), @almirb


1.1.0 Set, 12 2019
------------------

- Added `digitsOnly` property to validators
- Changed project structure
